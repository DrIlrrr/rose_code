C  List of function names. Actually defined in evinit.f
      INTEGER MFUN
      PARAMETER (MFUN=29)
      CHARACTER*(MCHAR) NAMFUN(MFUN)
      INTEGER NVFUN(MFUN)
      COMMON/EVFNLIS/NVFUN
      COMMON/EVFNLISC/NAMFUN
