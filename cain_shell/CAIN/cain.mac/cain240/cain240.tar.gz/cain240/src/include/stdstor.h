      CHARACTER*12 STDSTFL/'stdstore.dat'/,STDSTFLL/'stdstlum.dat'/
