#!/bin/bash
# ================================================
# a script run cain240 at kekcc 
# =================================================
export FORT8=caintdr.tdr

cain.exe < cain-input.i


